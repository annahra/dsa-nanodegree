"""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)


"""
TASK 1:
How many different telephone numbers are there in the records? 
Print a message:
"There are <count> different telephone numbers in the records."
"""

def countDistinctTeleNums(texts, calls):
    existingNums = set()
    numOfTeleNums = 0
    for row in texts:
        if not row[0] in existingNums:
            existingNums.add(row[0])
            numOfTeleNums += 1
        if not row[1] in existingNums:
            existingNums.add(row[1])
            numOfTeleNums += 1
    for row in calls:
        if not row[0] in existingNums:
            existingNums.add(row[0])
            numOfTeleNums += 1
        if not row[1] in existingNums:
            existingNums.add(row[1])
            numOfTeleNums += 1
    return numOfTeleNums

print(f"There are {countDistinctTeleNums(texts,calls)} different telephone numbers in the records.")