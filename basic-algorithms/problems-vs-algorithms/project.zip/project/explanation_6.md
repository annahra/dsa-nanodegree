Max and Min in an Unsorted Array

Space Complexity:
We are not using any extra space, so the space complexity of my solution is
O(1) constant space.

Time Complexity:
We are only iterating through the list once, so the time complexity of my solution
is O(n) linear time.