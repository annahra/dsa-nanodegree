Finding the Square Root

Data Structure Choice:
I did not use a data structure - instead, I simply used a while loop to reach the input
number. This makes the space complexity of my function O(1) constant time.

Time Complexity:
I square the current number until we reach the input number, this meams that we reach
the input number in O(logn) time. 
 